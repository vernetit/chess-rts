package com.burbuja.grabadora;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Lee las cabeceras de un archivo AAC/ADTS cuadro por cuadro.
 * Sirve para saber cuánto dura exactamente un tramo y hasta dónde está sano
 * (si el teléfono se apagó grabando, el último cuadro puede quedar cortado).
 */
final class Adts {
    private static final int[] RATES = {
            96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050,
            16000, 12000, 11025, 8000, 7350, 0, 0, 0
    };

    static final class Scan {
        long bytes;    // bytes válidos (cuadros completos) desde el inicio pedido
        long frames;
        long samples;
        int rate;

        long durMs() { return rate == 0 ? 0 : samples * 1000L / rate; }
    }

    private Adts() {}

    static Scan scan(File f, long from) throws IOException {
        Scan s = new Scan();
        long len = f.length();
        if (from >= len) return s;
        try (FileInputStream fis = new FileInputStream(f)) {
            fis.getChannel().position(from);
            InputStream in = new BufferedInputStream(fis, 1 << 16);
            byte[] h = new byte[7];
            long pos = from;
            while (pos + 7 <= len) {
                if (!readFully(in, h)) break;
                // sincronismo 0xFFF y layer 00
                if ((h[0] & 0xFF) != 0xFF || (h[1] & 0xF6) != 0xF0) break;
                boolean sinCrc = (h[1] & 0x01) == 1;
                int rate = RATES[(h[2] >> 2) & 0x0F];
                int frameLen = ((h[3] & 0x03) << 11) | ((h[4] & 0xFF) << 3) | ((h[5] & 0xE0) >> 5);
                int blocks = (h[6] & 0x03) + 1;
                int headerLen = sinCrc ? 7 : 9;
                if (rate == 0 || frameLen <= headerLen || pos + frameLen > len) break;
                if (!skipFully(in, frameLen - 7)) break;
                if (s.rate == 0) s.rate = rate;
                s.frames++;
                s.samples += 1024L * blocks;
                pos += frameLen;
                s.bytes = pos - from;
            }
        }
        return s;
    }

    private static boolean readFully(InputStream in, byte[] b) throws IOException {
        int off = 0;
        while (off < b.length) {
            int k = in.read(b, off, b.length - off);
            if (k < 0) return false;
            off += k;
        }
        return true;
    }

    private static boolean skipFully(InputStream in, long n) throws IOException {
        while (n > 0) {
            long k = in.skip(n);
            if (k <= 0) {
                if (in.read() < 0) return false;
                k = 1;
            }
            n -= k;
        }
        return true;
    }
}
