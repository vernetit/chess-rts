package com.burbuja.grabadora;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.media.AudioRecordingConfiguration;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.File;
import java.util.Locale;

/**
 * Servicio en primer plano (tipo micrófono) que muestra la burbuja sobre todas las apps
 * y graba. Tiene que arrancar con la app abierta: así Android le deja usar el micrófono
 * después, cuando tocás la burbuja desde cualquier otra app.
 */
public final class BubbleService extends Service {
    static final String ACT_SHOW = "com.burbuja.grabadora.SHOW";
    static final String ACT_TOGGLE = "com.burbuja.grabadora.TOGGLE";
    static final String ACT_CLOSE = "com.burbuja.grabadora.CLOSE";

    private static final String CH = "burbuja";
    private static final int NOTIF = 7;
    private static final int SAMPLE_RATE = 44100;   // fijo: todos los tramos del día iguales

    private static volatile boolean running, recordingNow;
    private static volatile String tempPath;

    static boolean isRunning() { return running; }

    static boolean isRecording() { return recordingNow; }

    static String currentTempPath() { return tempPath; }

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private BubbleView view;
    private WindowManager.LayoutParams lp;
    private int size, half, slop;
    private int dock = BubbleView.RIGHT;   // cómo está ahora
    private int wantDock = 0;              // a qué borde vuelve al terminar de grabar
    private boolean dead;

    private MediaRecorder rec;
    private File temp;
    private long segStart, segStartElapsed;
    private String segDay;
    private float level;
    private boolean silenced;
    private PowerManager.WakeLock wake;

    // toque
    private float downRawX, downRawY;
    private int downX, downY;
    private boolean dragging, longDone;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        createChannel();
        try {
            startForeground(NOTIF, build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } catch (RuntimeException e) {
            toast("Android no dejó arrancar la burbuja. Abrí la app y probá de nuevo.");
            dead = true;
            running = false;
            stopSelf();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Falta el permiso para mostrar sobre otras apps");
            shutdown();
            return;
        }
        addBubble();
        Store.recoverAsync(this);
        Bus.changed();
    }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        if (dead) return START_NOT_STICKY;
        String a = i == null ? null : i.getAction();
        if (ACT_TOGGLE.equals(a)) {
            if (rec == null) startRec(false);
            else stopRec(false);
        } else if (ACT_CLOSE.equals(a)) {
            Prefs.get(this).edit().putBoolean(Prefs.ON, false).apply();
            shutdown();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (rec != null) stopRec(true);
        h.removeCallbacksAndMessages(null);
        removeBubble();
        releaseWake();
        running = false;
        recordingNow = false;
        tempPath = null;
        Bus.changed();
        super.onDestroy();
    }

    private void shutdown() {
        if (rec != null) stopRec(true);
        dead = true;
        h.removeCallbacksAndMessages(null);
        removeBubble();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
        running = false;
        Bus.changed();
    }

    // ================= burbuja =================

    private void addBubble() {
        Context wctx = this;
        if (Build.VERSION.SDK_INT >= 30) {
            DisplayManager dm = getSystemService(DisplayManager.class);
            Display d = dm == null ? null : dm.getDisplay(Display.DEFAULT_DISPLAY);
            if (d != null) {
                wctx = createDisplayContext(d)
                        .createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null);
            }
        }
        wm = wctx.getSystemService(WindowManager.class);
        float dn = getResources().getDisplayMetrics().density;
        size = Math.round(64 * dn);
        half = size / 2;
        slop = ViewConfiguration.get(wctx).getScaledTouchSlop();

        view = new BubbleView(wctx);
        lp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;

        SharedPreferences p = Prefs.get(this);
        Point s = screen();
        dock = p.getInt(Prefs.DOCK, BubbleView.RIGHT);
        lp.x = p.getInt(Prefs.X, s.x - size);
        lp.y = p.getInt(Prefs.Y, s.y / 3);
        applyDock();
        view.setOnTouchListener(this::onTouch);
        try {
            wm.addView(view, lp);
        } catch (RuntimeException e) {
            view = null;
            toast("No pude mostrar la burbuja: " + e.getMessage());
            shutdown();
        }
    }

    private void removeBubble() {
        if (view != null && wm != null) {
            try {
                wm.removeView(view);
            } catch (RuntimeException ignored) {
            }
        }
        view = null;
    }

    private Point screen() {
        if (Build.VERSION.SDK_INT >= 30) {
            Rect b = wm.getCurrentWindowMetrics().getBounds();
            return new Point(b.width(), b.height());
        }
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new Point(dm.widthPixels, dm.heightPixels);
    }

    private int clampY(int y) {
        return Math.max(0, Math.min(y, screen().y - size));
    }

    /** Ajusta tamaño y posición de la ventana según esté suelta o escondida en un borde. */
    private void applyDock() {
        Point s = screen();
        if (dock == BubbleView.LEFT) {
            lp.width = half;
            lp.x = 0;
        } else if (dock == BubbleView.RIGHT) {
            lp.width = half;
            lp.x = s.x - half;
        } else {
            lp.width = size;
            lp.x = Math.max(0, Math.min(lp.x, s.x - size));
        }
        lp.y = clampY(lp.y);
        if (view != null) view.setMode(dock);
    }

    private void commit() {
        if (view == null) return;
        try {
            wm.updateViewLayout(view, lp);
        } catch (RuntimeException ignored) {
        }
        int d = (rec != null && wantDock != 0) ? wantDock : dock;
        Prefs.get(this).edit().putInt(Prefs.X, lp.x).putInt(Prefs.Y, lp.y).putInt(Prefs.DOCK, d).apply();
    }

    private final Runnable dockLater = () -> {
        if (rec != null || dragging || wantDock == 0 || view == null) return;
        dock = wantDock;
        wantDock = 0;
        applyDock();
        commit();
    };

    private final Runnable longPress = () -> {
        longDone = true;
        vibrate(new long[]{0, 25});
        openApp();
    };

    private boolean onTouch(View v, MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = e.getRawX();
                downRawY = e.getRawY();
                dragging = false;
                longDone = false;
                h.removeCallbacks(dockLater);
                h.postDelayed(longPress, ViewConfiguration.getLongPressTimeout());
                return true;

            case MotionEvent.ACTION_MOVE: {
                float dx = e.getRawX() - downRawX;
                float dy = e.getRawY() - downRawY;
                if (!dragging && !longDone && Math.hypot(dx, dy) > slop) {
                    dragging = true;
                    h.removeCallbacks(longPress);
                    if (dock != BubbleView.FULL) {
                        // sale del borde: ventana completa, centrada en el borde
                        Point s = screen();
                        lp.x = dock == BubbleView.LEFT ? -half : s.x - half;
                        lp.width = size;
                        dock = BubbleView.FULL;
                        view.setMode(BubbleView.FULL);
                    }
                    downX = lp.x - Math.round(dx);
                    downY = lp.y - Math.round(dy);
                }
                if (dragging) {
                    lp.x = downX + Math.round(dx);
                    lp.y = clampY(downY + Math.round(dy));
                    try {
                        wm.updateViewLayout(view, lp);
                    } catch (RuntimeException ignored) {
                    }
                }
                return true;
            }

            case MotionEvent.ACTION_UP:
                h.removeCallbacks(longPress);
                if (longDone) return true;
                if (dragging) {
                    dragging = false;
                    dragEnd();
                } else {
                    tap();
                }
                return true;

            case MotionEvent.ACTION_CANCEL:
                h.removeCallbacks(longPress);
                if (dragging) {
                    dragging = false;
                    dragEnd();
                }
                return true;
        }
        return false;
    }

    private void dragEnd() {
        Point s = screen();
        int cx = lp.x + half;
        int edge = Math.round(size * 0.9f);
        int side = cx < edge ? BubbleView.LEFT : cx > s.x - edge ? BubbleView.RIGHT : BubbleView.FULL;
        if (side == BubbleView.FULL) {
            dock = BubbleView.FULL;
            wantDock = 0;
        } else if (rec == null) {
            dock = side;          // cerca del borde: se esconde la mitad
            wantDock = 0;
        } else {
            dock = BubbleView.FULL;   // grabando: queda entera pegada al borde
            wantDock = side;          // y se esconde cuando pares
            lp.x = side == BubbleView.LEFT ? 0 : s.x - size;
        }
        applyDock();
        commit();
    }

    private void tap() {
        if (rec == null) {
            if (dock != BubbleView.FULL) {
                // estaba escondida: sale entera y graba
                Point s = screen();
                wantDock = dock;
                lp.x = dock == BubbleView.LEFT ? 0 : s.x - size;
                dock = BubbleView.FULL;
                applyDock();
                commit();
            }
            startRec(false);
        } else {
            stopRec(false);
        }
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            startActivity(i);
        } catch (RuntimeException ignored) {
        }
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        // al girar la pantalla, reacomodar
        h.postDelayed(() -> {
            if (view != null) {
                applyDock();
                commit();
            }
        }, 300);
    }

    // ================= grabación =================

    private void startRec(boolean quiet) {
        if (rec != null) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Falta el permiso de micrófono. Abrí la app.");
            openApp();
            redockSoon();
            return;
        }
        long now = System.currentTimeMillis();
        File f = Store.newTemp(this, now);
        MediaRecorder r = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC);
            r.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS);
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            r.setAudioChannels(1);
            r.setAudioSamplingRate(SAMPLE_RATE);
            r.setAudioEncodingBitRate(Prefs.get(this).getInt(Prefs.KBPS, 64) * 1000);
            r.setOutputFile(f.getAbsolutePath());
            r.prepare();
            r.start();
        } catch (Exception e) {
            r.release();
            f.delete();
            toast("No pude usar el micrófono (¿lo está usando otra app?)");
            redockSoon();
            return;
        }
        rec = r;
        temp = f;
        tempPath = f.getAbsolutePath();
        recordingNow = true;
        segStart = now;
        segStartElapsed = SystemClock.elapsedRealtime();
        segDay = Store.dayKey(now);
        silenced = false;
        level = 0;
        acquireWake();
        if (view != null) {
            view.setRecording(true);
            view.setLabel("0:00");
        }
        if (!quiet) vibrate(new long[]{0, 60});
        h.removeCallbacks(tick);
        h.post(tick);
        h.removeCallbacks(checkSilence);
        h.postDelayed(checkSilence, 1500);
        notifyUpdate();
        Bus.changed();
    }

    private void stopRec(boolean quiet) {
        if (rec == null) return;
        MediaRecorder r = rec;
        final File f = temp;
        rec = null;
        temp = null;
        tempPath = null;
        recordingNow = false;
        h.removeCallbacks(tick);
        h.removeCallbacks(checkSilence);
        try {
            r.stop();
        } catch (RuntimeException ignored) {
            // toque muy corto: no llegó a grabar nada
        }
        r.release();
        releaseWake();
        if (view != null) view.setRecording(false);
        if (!quiet) vibrate(new long[]{0, 35, 90, 35});
        final Context app = getApplicationContext();
        Store.IO.execute(() -> Store.finalizeTemp(app, f));
        Store.recoverAsync(app);
        notifyUpdate();
        Bus.changed();
        redockSoon();
    }

    private void redockSoon() {
        if (wantDock != 0) {
            h.removeCallbacks(dockLater);
            h.postDelayed(dockLater, 800);
        }
    }

    /** Cambio de día con la grabación andando: se cierra el tramo de ayer y sigue en el archivo de hoy. */
    private void rollover() {
        stopRec(true);
        h.removeCallbacks(dockLater);
        startRec(true);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (rec == null) return;
            try {
                float l = (float) Math.sqrt(rec.getMaxAmplitude() / 32767f);
                level = level * 0.6f + Math.min(1f, l) * 0.4f;
            } catch (RuntimeException ignored) {
            }
            long sec = (SystemClock.elapsedRealtime() - segStartElapsed) / 1000;
            if (view != null) {
                view.setLevel(level);
                view.setLabel(clock(sec));
            }
            if (!Store.dayKey(System.currentTimeMillis()).equals(segDay)) {
                rollover();
                return;
            }
            PowerManager pm = getSystemService(PowerManager.class);
            boolean on = pm == null || pm.isInteractive();
            h.postDelayed(this, on ? 120 : 2000);
        }
    };

    private final Runnable checkSilence = () -> {
        if (rec == null) return;
        try {
            AudioRecordingConfiguration cfg = rec.getActiveRecordingConfiguration();
            if (cfg != null && cfg.isClientSilenced()) {
                silenced = true;
                if (view != null) view.setWarn(true);
                toast("Android está silenciando el micrófono. Cerrá la burbuja y abrila de nuevo desde la app.");
                notifyUpdate();
            }
        } catch (RuntimeException ignored) {
        }
    };

    private static String clock(long sec) {
        long hh = sec / 3600, mm = (sec % 3600) / 60, ss = sec % 60;
        return hh > 0 ? String.format(Locale.ROOT, "%d:%02d:%02d", hh, mm, ss)
                : String.format(Locale.ROOT, "%d:%02d", mm, ss);
    }

    private void acquireWake() {
        if (wake == null) {
            PowerManager pm = getSystemService(PowerManager.class);
            if (pm == null) return;
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "burbuja:grabando");
            wake.setReferenceCounted(false);
        }
        wake.acquire(26L * 3600 * 1000);
    }

    private void releaseWake() {
        if (wake != null && wake.isHeld()) wake.release();
    }

    private void vibrate(long[] pattern) {
        try {
            Vibrator v = getSystemService(Vibrator.class);
            if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createWaveform(pattern, -1));
        } catch (RuntimeException ignored) {
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // ================= notificación =================

    private void createChannel() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CH, "Burbuja", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
    }

    private Notification build() {
        boolean r = rec != null;
        int fl = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(this, 1,
                new Intent(this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP), fl);
        PendingIntent tog = PendingIntent.getForegroundService(this, 2,
                new Intent(this, BubbleService.class).setAction(ACT_TOGGLE), fl);
        PendingIntent close = PendingIntent.getForegroundService(this, 3,
                new Intent(this, BubbleService.class).setAction(ACT_CLOSE), fl);
        Icon ic = Icon.createWithResource(this, R.drawable.ic_stat_mic);

        Notification.Builder b = new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat_mic)
                .setContentTitle(r ? (silenced ? "Grabando — micrófono silenciado por Android" : "Grabando")
                        : "Burbuja lista")
                .setContentText(r ? "Tocá la burbuja para parar"
                        : "Tocá la burbuja para grabar. Mantenela apretada para ver las grabaciones.")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(ic, r ? "Parar" : "Grabar", tog).build())
                .addAction(new Notification.Action.Builder(ic, "Cerrar burbuja", close).build());
        if (r) {
            b.setUsesChronometer(true).setWhen(segStart).setShowWhen(true);
        } else {
            b.setShowWhen(false);
        }
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    private void notifyUpdate() {
        if (dead) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIF, build());
    }
}
