package com.burbuja.grabadora;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

/**
 * Archivos:
 *   grabaciones/2026-10-30.aac   audio del día entero (tramos pegados uno atrás del otro)
 *   grabaciones/2026-10-30.idx   un renglón por tramo: inicio,offset,bytes,muestras,frecuencia
 *   grabaciones/seg-<ms>.part    tramo que se está grabando (o que quedó colgado)
 *
 * Cada tramo se graba aparte y al parar se pega al final del archivo del día.
 * AAC en formato ADTS se puede pegar así sin rearmar nada.
 */
final class Store {
    private static final String TAG = "Burbuja";
    static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Pattern DAY = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");

    static final class Seg {
        final long start;     // hora real de inicio (ms)
        final long offset;    // posición en el archivo del día
        final long bytes;
        final long samples;
        final int rate;

        Seg(long start, long offset, long bytes, long samples, int rate) {
            this.start = start;
            this.offset = offset;
            this.bytes = bytes;
            this.samples = samples;
            this.rate = rate;
        }

        long durMs() { return rate == 0 ? 0 : samples * 1000L / rate; }

        long end() { return offset + bytes; }

        String line() {
            return String.format(Locale.ROOT, "%d,%d,%d,%d,%d", start, offset, bytes, samples, rate);
        }
    }

    static final class Day {
        String key;
        File audio;
        List<Seg> segs = new ArrayList<>();
        long totalMs;
        long size;
    }

    private static final class Index {
        final List<Seg> segs = new ArrayList<>();
        boolean dirty;
    }

    private Store() {}

    // ---------- rutas ----------

    static File dir(Context c) {
        File base = c.getExternalFilesDir(null);
        if (base == null) base = c.getFilesDir();
        File d = new File(base, "grabaciones");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    static String dayKey(long millis) {
        return Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate().toString();
    }

    static File audio(Context c, String day) { return new File(dir(c), day + ".aac"); }

    static File index(Context c, String day) { return new File(dir(c), day + ".idx"); }

    static File newTemp(Context c, long start) { return new File(dir(c), "seg-" + start + ".part"); }

    static long tempStart(File f) {
        String n = f.getName();
        try {
            return Long.parseLong(n.substring(4, n.length() - 5));
        } catch (RuntimeException e) {
            return f.lastModified();
        }
    }

    // ---------- índice ----------

    private static Index readIndex(File x) {
        Index r = new Index();
        if (!x.exists()) return r;
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(x), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] p = line.split(",");
                try {
                    if (p.length != 5) throw new NumberFormatException();
                    r.segs.add(new Seg(Long.parseLong(p[0]), Long.parseLong(p[1]),
                            Long.parseLong(p[2]), Long.parseLong(p[3]), Integer.parseInt(p[4])));
                } catch (NumberFormatException e) {
                    r.dirty = true;
                }
            }
        } catch (IOException e) {
            r.dirty = true;
        }
        // el último renglón tiene que terminar en salto de línea
        try (RandomAccessFile raf = new RandomAccessFile(x, "r")) {
            long n = raf.length();
            if (n > 0) {
                raf.seek(n - 1);
                if (raf.read() != '\n') r.dirty = true;
            }
        } catch (IOException ignored) {
        }
        return r;
    }

    private static void writeIndex(File x, List<Seg> segs) throws IOException {
        File tmp = new File(x.getPath() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            StringBuilder sb = new StringBuilder();
            for (Seg s : segs) sb.append(s.line()).append('\n');
            out.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        }
        if (!tmp.renameTo(x)) throw new IOException("no pude reemplazar " + x.getName());
    }

    private static void appendLine(File x, String line) throws IOException {
        try (FileOutputStream out = new FileOutputStream(x, true)) {
            out.write((line + "\n").getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        }
    }

    private static void truncate(File a, long len) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(a, "rw")) {
            raf.setLength(len);
        }
    }

    /** Deja audio e índice de acuerdo entre sí. Devuelve los tramos válidos. */
    private static List<Seg> consistent(File a, File x) throws IOException {
        Index ix = readIndex(x);
        long len = a.exists() ? a.length() : 0;
        List<Seg> segs = ix.segs;
        int keep = segs.size();
        while (keep > 0 && segs.get(keep - 1).end() > len) keep--;
        boolean dropped = keep < segs.size();
        segs = new ArrayList<>(segs.subList(0, keep));
        if (ix.dirty || dropped) writeIndex(x, segs);
        long end = keep == 0 ? 0 : segs.get(keep - 1).end();
        if (len > end) {
            if (dropped) {
                // un pegado quedó a medias: se corta y se vuelve a pegar desde el .part
                truncate(a, end);
            } else {
                // hay audio sin anotar: se rescata como un tramo más
                Adts.Scan sc = Adts.scan(a, end);
                if (sc.frames > 0) {
                    Seg s = new Seg(Math.max(0, a.lastModified() - sc.durMs()), end,
                            sc.bytes, sc.samples, sc.rate);
                    appendLine(x, s.line());
                    segs.add(s);
                }
                if (len > end + sc.bytes) truncate(a, end + sc.bytes);
            }
        }
        return segs;
    }

    // ---------- pegar un tramo al día ----------

    static synchronized void finalizeTemp(Context c, File tmp) {
        try {
            if (tmp == null || !tmp.exists()) return;
            long start = tempStart(tmp);
            String day = dayKey(start);
            File a = audio(c, day);
            File x = index(c, day);
            List<Seg> segs = consistent(a, x);
            for (Seg s : segs) {
                if (s.start == start) {          // ya estaba pegado
                    tmp.delete();
                    Bus.changed();
                    return;
                }
            }
            Adts.Scan sc = Adts.scan(tmp, 0);
            if (sc.frames == 0) {                // tramo vacío (toque muy corto)
                tmp.delete();
                return;
            }
            long offset = segs.isEmpty() ? 0 : segs.get(segs.size() - 1).end();
            Seg seg = new Seg(start, offset, sc.bytes, sc.samples, sc.rate);
            appendLine(x, seg.line());           // primero se anota...
            appendAudio(a, tmp, sc.bytes);       // ...después se pega...
            tmp.delete();                        // ...y recién ahí se borra el tramo suelto
        } catch (IOException e) {
            Log.e(TAG, "No pude guardar el tramo " + tmp, e);
        }
        Bus.changed();
    }

    private static void appendAudio(File a, File tmp, long n) throws IOException {
        try (FileInputStream in = new FileInputStream(tmp);
             FileOutputStream out = new FileOutputStream(a, true)) {
            FileChannel ic = in.getChannel();
            FileChannel oc = out.getChannel();
            long done = 0;
            while (done < n) {
                long k = ic.transferTo(done, n - done, oc);
                if (k <= 0) throw new IOException("copia incompleta");
                done += k;
            }
            out.getFD().sync();
        }
    }

    /** Pega los tramos que quedaron colgados (por ejemplo si Android cerró la app grabando). */
    static void recoverAsync(Context c) {
        final Context app = c.getApplicationContext();
        IO.execute(() -> {
            File[] fs = dir(app).listFiles((d, n) -> n.startsWith("seg-") && n.endsWith(".part"));
            if (fs == null || fs.length == 0) return;
            Arrays.sort(fs, Comparator.comparingLong(Store::tempStart));
            for (File f : fs) {
                String cur = BubbleService.currentTempPath();
                if (f.getAbsolutePath().equals(cur)) continue;                 // se está grabando
                if (System.currentTimeMillis() - f.lastModified() < 15000) continue; // muy reciente
                finalizeTemp(app, f);
            }
        });
    }

    // ---------- listar y borrar ----------

    static List<Day> listDays(Context c) {
        List<Day> out = new ArrayList<>();
        File[] fs = dir(c).listFiles((d, n) -> n.endsWith(".aac")
                && DAY.matcher(n.substring(0, n.length() - 4)).matches());
        if (fs == null) return out;
        for (File f : fs) {
            Day d = new Day();
            d.key = f.getName().substring(0, f.getName().length() - 4);
            d.audio = f;
            d.size = f.length();
            for (Seg s : readIndex(index(c, d.key)).segs) {
                if (s.end() <= d.size) {
                    d.segs.add(s);
                    d.totalMs += s.durMs();
                }
            }
            if (d.size > 0) out.add(d);
        }
        Collections.sort(out, (p, q) -> q.key.compareTo(p.key));
        return out;
    }

    static void deleteDay(Context c, String day) {
        audio(c, day).delete();
        index(c, day).delete();
    }
}
