package com.burbuja.grabadora;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.CopyOnWriteArrayList;

/** Aviso simple dentro de la app: "algo cambió" (se grabó un tramo, arrancó/paró la burbuja). */
final class Bus {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final CopyOnWriteArrayList<Runnable> LISTENERS = new CopyOnWriteArrayList<>();

    private Bus() {}

    static void add(Runnable r) { LISTENERS.addIfAbsent(r); }

    static void remove(Runnable r) { LISTENERS.remove(r); }

    static void changed() {
        MAIN.post(() -> {
            for (Runnable r : LISTENERS) r.run();
        });
    }
}
