package com.burbuja.grabadora;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int C_BG = 0xFF121417, C_CARD = 0xFF1E2227, C_HI = 0xFF323A42,
            C_TEXT = 0xFFECEFF1, C_SUB = 0xFF9AA4AD, C_RED = 0xFFE53935, C_BTN = 0xFF2F363D;
    private static final Locale ES = Locale.forLanguageTag("es-AR");
    private static final float[] SPEEDS = {1f, 1.25f, 1.5f, 2f};

    private final Handler h = new Handler(Looper.getMainLooper());
    private float dp;
    private LinearLayout permsBox, daysBox;
    private Button bubbleBtn, recBtn;
    private TextView status;
    private String openDay;                 // día desplegado

    // reproductor
    private MediaPlayer mp;
    private String mpDay;
    private long mpSize;
    private boolean mpReady;
    private long pendingSeek = -1;
    private boolean playWhenReady;
    private int speedIdx;
    private String resumeDay;               // día que se recargó porque creció
    private long resumePos;

    // vista del día desplegado
    private Store.Day shownDay;
    private SeekBar seek;
    private TextView posText;
    private Button playBtn, speedBtn;
    private final List<TextView> segViews = new ArrayList<>();
    private int litSeg = -2;
    private boolean userSeeking;

    private final Runnable refresher = this::refresh;
    private final Runnable uiTick = new Runnable() {
        @Override
        public void run() {
            updatePlayerUi();
            h.postDelayed(this, 300);
        }
    };

    // ================= ciclo de vida =================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dp = getResources().getDisplayMetrics().density;

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(C_BG);
        LinearLayout root = vbox();
        root.setPadding(px(16), px(20), px(16), px(40));
        sv.addView(root);
        setContentView(sv);

        root.addView(text("Burbuja", 26, C_TEXT, true));
        status = text("", 14, C_SUB, false);
        root.addView(status, lpw(0, 4, 0, 12));

        permsBox = vbox();
        root.addView(permsBox);

        LinearLayout row = hbox();
        bubbleBtn = button("", C_BTN, v -> toggleBubble());
        recBtn = button("", C_RED, v -> sendToggle());
        row.addView(bubbleBtn, weight(0));
        row.addView(recBtn, weight(10));
        root.addView(row, lpw(0, 8, 0, 8));

        root.addView(text("Calidad (vale para lo próximo que grabes)", 13, C_SUB, false), lpw(0, 12, 0, 4));
        root.addView(qualityGroup());

        root.addView(text("Grabaciones", 20, C_TEXT, true), lpw(0, 24, 0, 8));
        daysBox = vbox();
        root.addView(daysBox);

        root.addView(text("Burbuja: tocar = grabar / parar · arrastrar = mover · "
                + "soltarla cerca del borde = se esconde a medias · mantener apretada = abre esta pantalla.\n"
                + "Cada día es un solo archivo: los tramos se van sumando. "
                + "El tramo que se está grabando aparece acá cuando parás.", 13, C_SUB, false), lpw(0, 20, 0, 0));

        Store.recoverAsync(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Bus.add(refresher);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPerms();
        autoStart();
        refresh();
        h.removeCallbacks(uiTick);
        h.post(uiTick);
    }

    @Override
    protected void onPause() {
        h.removeCallbacks(uiTick);
        super.onPause();
    }

    @Override
    protected void onStop() {
        Bus.remove(refresher);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }

    // ================= permisos y burbuja =================

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasNotif() {
        return Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasOverlay() { return Settings.canDrawOverlays(this); }

    private boolean batteryOk() {
        PowerManager pm = getSystemService(PowerManager.class);
        return pm == null || pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private void refreshPerms() {
        permsBox.removeAllViews();
        if (!hasMic() || !hasNotif()) {
            permsBox.addView(button("1. Permitir micrófono y notificaciones", C_RED, v -> askRuntime()),
                    lpw(0, 0, 0, 8));
        }
        if (!hasOverlay()) {
            permsBox.addView(button("2. Permitir mostrar sobre otras apps", C_RED, v -> {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                } catch (RuntimeException e) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
                }
            }), lpw(0, 0, 0, 8));
        }
        if (!batteryOk()) {
            permsBox.addView(button("Opcional: batería sin restricciones (que Android no la cierre)",
                    C_BTN, v -> askBattery()), lpw(0, 0, 0, 8));
        }
        updateButtons();
    }

    private void askRuntime() {
        List<String> p = new ArrayList<>();
        if (!hasMic()) p.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && !hasNotif()) p.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), 1);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (!hasMic() && !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            // negado para siempre: hay que darlo a mano en Ajustes
            toast("Dale el permiso de micrófono en Ajustes → Permisos");
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
        refreshPerms();
        autoStart();
    }

    private void askBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (RuntimeException e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private boolean ready() { return hasMic() && hasOverlay(); }

    /** Al abrir la app, si la burbuja tenía que estar y no está (por ejemplo después de reiniciar), la levanta. */
    private void autoStart() {
        if (ready() && Prefs.get(this).getBoolean(Prefs.ON, true) && !BubbleService.isRunning()) {
            startBubble(BubbleService.ACT_SHOW);
        }
    }

    private void startBubble(String action) {
        Prefs.get(this).edit().putBoolean(Prefs.ON, true).apply();
        try {
            startForegroundService(new Intent(this, BubbleService.class).setAction(action));
        } catch (RuntimeException e) {
            toast("No pude arrancar la burbuja: " + e.getMessage());
        }
        h.postDelayed(this::updateButtons, 400);
    }

    private void toggleBubble() {
        if (BubbleService.isRunning()) {
            startService(new Intent(this, BubbleService.class).setAction(BubbleService.ACT_CLOSE));
        } else if (ready()) {
            startBubble(BubbleService.ACT_SHOW);
        } else {
            toast("Primero dale los permisos de arriba");
        }
        h.postDelayed(this::updateButtons, 400);
    }

    private void sendToggle() {
        if (!ready()) {
            toast("Primero dale los permisos de arriba");
            return;
        }
        if (BubbleService.isRunning()) {
            startService(new Intent(this, BubbleService.class).setAction(BubbleService.ACT_TOGGLE));
        } else {
            startBubble(BubbleService.ACT_TOGGLE);
        }
    }

    private void updateButtons() {
        boolean run = BubbleService.isRunning(), rec = BubbleService.isRecording();
        bubbleBtn.setText(run ? "Cerrar burbuja" : "Mostrar burbuja");
        recBtn.setText(rec ? "■  Parar" : "●  Grabar");
        status.setText(!ready() ? "Faltan permisos."
                : rec ? "Grabando…"
                : run ? "Burbuja activa. Tocála para grabar."
                : "Burbuja cerrada.");
    }

    private View qualityGroup() {
        RadioGroup g = new RadioGroup(this);
        g.setOrientation(RadioGroup.VERTICAL);
        int[] kb = {32, 64, 128};
        String[] nm = {"Baja · 32 kbps · ~14 MB por hora", "Media · 64 kbps · ~29 MB por hora",
                "Alta · 128 kbps · ~58 MB por hora"};
        int cur = Prefs.get(this).getInt(Prefs.KBPS, 64);
        for (int i = 0; i < kb.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(View.generateViewId());
            rb.setText(nm[i]);
            rb.setTextColor(C_TEXT);
            rb.setTextSize(15);
            rb.setButtonTintList(ColorStateList.valueOf(C_RED));
            final int k = kb[i];
            g.addView(rb);
            if (k == cur) rb.setChecked(true);
            rb.setOnCheckedChangeListener((bt, on) -> {
                if (on) Prefs.get(this).edit().putInt(Prefs.KBPS, k).apply();
            });
        }
        return g;
    }

    // ================= lista de días =================

    private void refresh() {
        if (daysBox == null) return;
        updateButtons();
        List<Store.Day> days = Store.listDays(this);

        // si el día que estaba cargado creció o se borró, recargar el reproductor (sin cortar si suena)
        if (mp != null && mpReady && !isPlaying()) {
            Store.Day same = null;
            for (Store.Day d : days) if (d.key.equals(mpDay)) same = d;
            if (same == null || same.size != mpSize) {
                String k = mpDay;
                long pos = safePos();
                releasePlayer();
                if (same != null) {
                    resumeDay = k;
                    resumePos = pos;
                }
            }
        }

        daysBox.removeAllViews();
        segViews.clear();
        shownDay = null;
        seek = null;
        posText = null;
        playBtn = null;
        speedBtn = null;
        litSeg = -2;

        String today = Store.dayKey(System.currentTimeMillis());
        boolean todayListed = false;
        for (Store.Day d : days) {
            if (d.key.equals(today)) todayListed = true;
            daysBox.addView(dayCard(d, today), lpw(0, 0, 0, 10));
        }
        if (BubbleService.isRecording() && !todayListed) {
            daysBox.addView(text("● Hoy: grabando el primer tramo. Aparece acá cuando pares.", 14, C_RED, false),
                    0, lpw(0, 0, 0, 10));
        }
        if (days.isEmpty() && !BubbleService.isRecording()) {
            daysBox.addView(text("Todavía no hay grabaciones.", 15, C_SUB, false));
        }
        updatePlayerUi();
    }

    private View dayCard(Store.Day d, String today) {
        LinearLayout card = vbox();
        card.setBackground(round(C_CARD, 14));
        card.setPadding(px(14), px(12), px(14), px(12));

        boolean open = d.key.equals(openDay);
        LinearLayout head = vbox();
        head.addView(text((open ? "▾ " : "▸ ") + dayTitle(d.key), 17, C_TEXT, true));
        String sum = dur(d.totalMs) + " · " + d.segs.size() + (d.segs.size() == 1 ? " tramo" : " tramos")
                + " · " + mb(d.size);
        head.addView(text(sum, 13, C_SUB, false));
        if (d.key.equals(today) && BubbleService.isRecording()) {
            head.addView(text("● grabando un tramo más (aparece cuando pares)", 13, C_RED, false));
        }
        head.setOnClickListener(v -> {
            openDay = open ? null : d.key;
            refresh();
        });
        card.addView(head);
        if (open) addPlayer(card, d);
        return card;
    }

    private void addPlayer(LinearLayout card, Store.Day d) {
        shownDay = d;

        seek = new SeekBar(this);
        seek.setMax((int) Math.max(1, d.totalMs));
        seek.setProgressTintList(ColorStateList.valueOf(C_RED));
        seek.setThumbTintList(ColorStateList.valueOf(C_RED));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                if (fromUser && posText != null) posText.setText(posLabel(d, p));
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) { userSeeking = true; }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                userSeeking = false;
                seekTo(d, sb.getProgress(), isPlaying() || playWhenReady);
            }
        });
        card.addView(seek, lpw(0, 12, 0, 0));

        posText = text("Tocá ▶ o un tramo para escuchar", 14, C_SUB, false);
        posText.setGravity(Gravity.CENTER_HORIZONTAL);
        card.addView(posText, lpw(0, 2, 0, 6));

        LinearLayout ctr = hbox();
        ctr.addView(button("−15 s", C_BTN, v -> skip(d, -15000)), weight(0));
        playBtn = button("▶", C_RED, v -> playPause(d));
        ctr.addView(playBtn, weight(8));
        ctr.addView(button("+15 s", C_BTN, v -> skip(d, 15000)), weight(8));
        speedBtn = button(speedLabel(), C_BTN, v -> cycleSpeed());
        ctr.addView(speedBtn, weight(8));
        card.addView(ctr);

        card.addView(text("Tramos", 13, C_SUB, false), lpw(0, 14, 0, 2));
        long cum = 0;
        int i = 1;
        for (Store.Seg s : d.segs) {
            final long at = cum;
            TextView tv = text(i + ".   " + clockOf(s.start) + "   ·   " + dur(s.durMs()), 15, C_TEXT, false);
            tv.setPadding(px(8), px(10), px(8), px(10));
            tv.setOnClickListener(v -> seekTo(d, at, true));
            card.addView(tv);
            segViews.add(tv);
            cum += s.durMs();
            i++;
        }

        LinearLayout act = hbox();
        act.addView(button("Compartir", C_BTN, v -> share(d)), weight(0));
        act.addView(button("A Descargas", C_BTN, v -> toDownloads(d)), weight(8));
        act.addView(button("Borrar", C_BTN, v -> confirmDelete(d)), weight(8));
        card.addView(act, lpw(0, 12, 0, 0));
    }

    // ================= reproductor =================

    private boolean isPlaying() {
        try {
            return mp != null && mpReady && mp.isPlaying();
        } catch (IllegalStateException e) {
            return false;
        }
    }

    private long safePos() {
        try {
            return mp.getCurrentPosition();
        } catch (IllegalStateException e) {
            return 0;
        }
    }

    private void ensurePlayer(Store.Day d) {
        if (mp != null && d.key.equals(mpDay)) return;
        releasePlayer();
        if (d.key.equals(resumeDay)) pendingSeek = resumePos;   // seguir donde estaba
        resumeDay = null;
        mp = new MediaPlayer();
        mp.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build());
        mpDay = d.key;
        mpSize = d.size;
        mpReady = false;
        try {
            mp.setDataSource(d.audio.getAbsolutePath());
        } catch (IOException e) {
            toast("No pude abrir el audio");
            releasePlayer();
            return;
        }
        mp.setOnPreparedListener(p -> {
            mpReady = true;
            if (pendingSeek >= 0) {
                p.seekTo(pendingSeek, MediaPlayer.SEEK_CLOSEST);
                pendingSeek = -1;
            }
            if (playWhenReady) startPlay();
            updatePlayerUi();
        });
        mp.setOnCompletionListener(p -> updatePlayerUi());
        mp.setOnErrorListener((p, what, extra) -> {
            toast("Error al reproducir (" + what + ")");
            releasePlayer();
            updatePlayerUi();
            return true;
        });
        mp.prepareAsync();
    }

    private void releasePlayer() {
        if (mp != null) {
            try {
                mp.release();
            } catch (RuntimeException ignored) {
            }
        }
        mp = null;
        mpDay = null;
        mpReady = false;
        pendingSeek = -1;
        playWhenReady = false;
    }

    private void startPlay() {
        if (mp == null || !mpReady) return;
        playWhenReady = false;
        try {
            mp.start();
            mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(SPEEDS[speedIdx]));
        } catch (RuntimeException ignored) {
        }
    }

    private void playPause(Store.Day d) {
        ensurePlayer(d);
        if (mp == null) return;
        if (!mpReady) {
            playWhenReady = !playWhenReady;
        } else if (isPlaying()) {
            mp.pause();
        } else {
            startPlay();
        }
        updatePlayerUi();
    }

    private void seekTo(Store.Day d, long ms, boolean play) {
        ensurePlayer(d);
        if (mp == null) return;
        if (mpReady) {
            mp.seekTo(ms, MediaPlayer.SEEK_CLOSEST);
            if (play && !isPlaying()) startPlay();
        } else {
            pendingSeek = ms;
            if (play) playWhenReady = true;
        }
        updatePlayerUi();
    }

    private void skip(Store.Day d, long delta) {
        if (mp == null || !d.key.equals(mpDay) || !mpReady) return;
        long pos = Math.max(0, Math.min(d.totalMs, safePos() + delta));
        seekTo(d, pos, isPlaying());
    }

    private void cycleSpeed() {
        speedIdx = (speedIdx + 1) % SPEEDS.length;
        if (speedBtn != null) speedBtn.setText(speedLabel());
        if (isPlaying()) {
            try {
                mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(SPEEDS[speedIdx]));
            } catch (RuntimeException ignored) {
            }
        }
    }

    private String speedLabel() {
        float s = SPEEDS[speedIdx];
        return (s == (int) s ? String.valueOf((int) s) : String.valueOf(s).replace('.', ',')) + "×";
    }

    private void updatePlayerUi() {
        if (shownDay == null || seek == null || posText == null || playBtn == null) return;
        boolean mine = mp != null && shownDay.key.equals(mpDay);
        playBtn.setText(mine && (isPlaying() || (!mpReady && playWhenReady)) ? "❚❚" : "▶");
        long pos;
        if (mine && mpReady) pos = safePos();
        else if (mine) pos = -2;                       // cargando
        else pos = shownDay.key.equals(resumeDay) ? resumePos : -1;
        if (pos == -2) {
            posText.setText("Cargando…");
            return;
        }
        if (pos < 0) {
            posText.setText("Tocá ▶ o un tramo para escuchar");
            light(-1);
            return;
        }
        if (!userSeeking) {
            seek.setProgress((int) pos);
            posText.setText(posLabel(shownDay, pos));
        }
        light(segIndex(shownDay, pos));
    }

    private void light(int idx) {
        if (idx == litSeg) return;
        for (int i = 0; i < segViews.size(); i++) {
            segViews.get(i).setBackground(i == idx ? round(C_HI, 8) : null);
        }
        litSeg = idx;
    }

    private static int segIndex(Store.Day d, long pos) {
        long cum = 0;
        for (int i = 0; i < d.segs.size(); i++) {
            long du = d.segs.get(i).durMs();
            if (pos < cum + du) return i;
            cum += du;
        }
        return d.segs.isEmpty() ? -1 : d.segs.size() - 1;
    }

    /** "12:03 de 2:13:00 · grabado a las 21:05:32" */
    private String posLabel(Store.Day d, long pos) {
        String s = clockDur(pos) + " de " + clockDur(d.totalMs);
        int i = segIndex(d, pos);
        if (i >= 0) {
            long cum = 0;
            for (int k = 0; k < i; k++) cum += d.segs.get(k).durMs();
            s += "  ·  grabado a las " + clockOf(d.segs.get(i).start + (pos - cum));
        }
        return s;
    }

    // ================= compartir, copiar, borrar =================

    private void share(Store.Day d) {
        Uri u = RecProvider.uri(d.key);
        Intent s = new Intent(Intent.ACTION_SEND)
                .setType("audio/aac")
                .putExtra(Intent.EXTRA_STREAM, u)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        s.setClipData(ClipData.newRawUri("grabacion-" + d.key, u));
        try {
            startActivity(Intent.createChooser(s, "Compartir " + d.key));
        } catch (RuntimeException e) {
            toast("No hay apps para compartir audio");
        }
    }

    private void toDownloads(Store.Day d) {
        final Context app = getApplicationContext();
        final String name = "grabacion-" + d.key + ".aac";
        toast("Copiando a Descargas/Grabaciones…");
        Store.IO.execute(() -> {
            String msg;
            try {
                ContentResolver cr = app.getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "audio/aac");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Grabaciones");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) throw new IOException("Android no dio lugar en Descargas");
                try (InputStream in = new FileInputStream(d.audio);
                     OutputStream out = cr.openOutputStream(u)) {
                    if (out == null) throw new IOException("no se pudo escribir");
                    byte[] buf = new byte[1 << 16];
                    int k;
                    while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
                }
                v.clear();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(u, v, null, null);
                msg = "Listo: Descargas/Grabaciones/" + name;
            } catch (Exception e) {
                msg = "No se pudo copiar: " + e.getMessage();
            }
            final String m = msg;
            h.post(() -> Toast.makeText(app, m, Toast.LENGTH_LONG).show());
        });
    }

    private void confirmDelete(Store.Day d) {
        final Context app = getApplicationContext();
        new AlertDialog.Builder(this)
                .setTitle("¿Borrar " + dayTitle(d.key) + "?")
                .setMessage(dur(d.totalMs) + " de grabación. No se puede deshacer.")
                .setPositiveButton("Borrar", (dlg, w) -> {
                    if (d.key.equals(mpDay)) releasePlayer();
                    if (d.key.equals(openDay)) openDay = null;
                    Store.IO.execute(() -> {
                        Store.deleteDay(app, d.key);
                        Bus.changed();
                    });
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ================= formatos =================

    private static String dayTitle(String key) {
        LocalDate d = LocalDate.parse(key), today = LocalDate.now();
        String pat = d.getYear() == today.getYear() ? "EEEE d 'de' MMMM" : "EEEE d 'de' MMMM 'de' yyyy";
        String base = d.format(DateTimeFormatter.ofPattern(pat, ES));
        if (d.equals(today)) return "Hoy · " + base;
        if (d.equals(today.minusDays(1))) return "Ayer · " + base;
        return base.isEmpty() ? key : Character.toUpperCase(base.charAt(0)) + base.substring(1);
    }

    private static String dur(long ms) {
        long s = ms / 1000, hh = s / 3600, mm = (s % 3600) / 60, ss = s % 60;
        if (hh > 0) return hh + " h " + mm + " min";
        if (mm > 0) return mm + " min " + ss + " s";
        return ss + " s";
    }

    private static String clockDur(long ms) {
        long s = ms / 1000, hh = s / 3600, mm = (s % 3600) / 60, ss = s % 60;
        return hh > 0 ? String.format(Locale.ROOT, "%d:%02d:%02d", hh, mm, ss)
                : String.format(Locale.ROOT, "%d:%02d", mm, ss);
    }

    private static String clockOf(long millis) {
        return Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault())
                .format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }

    private static String mb(long bytes) {
        return String.format(ES, "%.1f MB", bytes / 1048576.0);
    }

    // ================= vistas =================

    private int px(float v) { return Math.round(v * dp); }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String s, int bg, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(15);
        b.setMinHeight(px(48));
        b.setStateListAnimator(null);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), round(bg, 12), null));
        b.setPadding(px(10), px(10), px(10), px(10));
        b.setOnClickListener(l);
        return b;
    }

    private Drawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusDp * dp);
        return g;
    }

    private LinearLayout.LayoutParams lpw(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(px(l), px(t), px(r), px(b));
        return p;
    }

    private LinearLayout.LayoutParams weight(int leftMarginDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.leftMargin = px(leftMarginDp);
        return p;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
