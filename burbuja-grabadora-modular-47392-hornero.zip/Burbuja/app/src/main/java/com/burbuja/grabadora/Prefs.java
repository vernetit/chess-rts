package com.burbuja.grabadora;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String ON = "activa";     // la burbuja debe estar visible
    static final String KBPS = "kbps";     // calidad: 32 / 64 / 128
    static final String X = "x";
    static final String Y = "y";
    static final String DOCK = "dock";     // 0 suelta, 1 izquierda, 2 derecha

    private Prefs() {}

    static SharedPreferences get(Context c) {
        return c.getSharedPreferences("burbuja", Context.MODE_PRIVATE);
    }
}
