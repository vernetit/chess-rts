package com.burbuja.grabadora;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/**
 * La burbuja. Se dibuja sola, sin imágenes.
 *  - gris con micrófono: lista para grabar
 *  - roja con el tiempo: grabando (el aro crece con el volumen)
 *  - naranja: grabando pero Android está silenciando el micrófono
 * Escondida en un borde, la ventana mide la mitad y se ve medio círculo.
 */
final class BubbleView extends View {
    static final int FULL = 0, LEFT = 1, RIGHT = 2;

    private static final int GRIS = 0xFF37474F, ROJO = 0xFFE53935, NARANJA = 0xFFFB8C00;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint white = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float dn;

    private int mode = FULL;
    private boolean recording, warn;
    private float level;
    private String label = "";

    BubbleView(Context c) {
        super(c);
        dn = getResources().getDisplayMetrics().density;
        white.setColor(0xFFFFFFFF);
        line.setColor(0xFFFFFFFF);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        border.setColor(0x55FFFFFF);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(1.5f * dn);
        shadow.setColor(0x55000000);
        text.setColor(0xFFFFFFFF);
        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
    }

    void setMode(int m) {
        mode = m;
        setAlpha(m == FULL ? 1f : 0.75f);
        invalidate();
    }

    void setRecording(boolean r) {
        recording = r;
        if (!r) {
            warn = false;
            level = 0;
            label = "";
        }
        invalidate();
    }

    void setWarn(boolean w) { warn = w; invalidate(); }

    void setLevel(float l) { level = l; invalidate(); }

    void setLabel(String s) {
        if (!s.equals(label)) {
            label = s;
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        float h = getHeight();
        float r = h * 0.40f;
        float cx = mode == LEFT ? 0 : mode == RIGHT ? getWidth() : getWidth() / 2f;
        float cy = h / 2f;

        if (recording) {
            float rr = r + (h / 2f - r) * Math.min(1f, 0.15f + level);
            ring.setColor(warn ? 0x66FB8C00 : 0x66E53935);
            c.drawCircle(cx, cy, rr, ring);
        } else {
            c.drawCircle(cx, cy + dn, r + dn, shadow);
        }

        fill.setColor(recording ? (warn ? NARANJA : ROJO) : GRIS);
        c.drawCircle(cx, cy, r, fill);
        c.drawCircle(cx, cy, r - 0.75f * dn, border);

        if (recording && !label.isEmpty()) {
            text.setTextSize(label.length() > 5 ? r * 0.42f : r * 0.56f);
            Paint.FontMetrics fm = text.getFontMetrics();
            c.drawText(label, cx, cy - (fm.ascent + fm.descent) / 2f, text);
        } else if (mode == FULL) {
            drawMic(c, cx, cy, r);
        } else {
            // medio escondida: micrófono chico en la mitad que se ve
            float off = r * 0.48f;
            drawMic(c, mode == LEFT ? cx + off : cx - off, cy, r * 0.62f);
        }
    }

    private void drawMic(Canvas c, float cx, float cy, float r) {
        float w = r * 0.22f;
        rect.set(cx - w, cy - r * 0.58f, cx + w, cy + r * 0.12f);
        c.drawRoundRect(rect, w, w, white);
        line.setStrokeWidth(Math.max(1.5f * dn, r * 0.09f));
        rect.set(cx - r * 0.38f, cy - r * 0.42f, cx + r * 0.38f, cy + r * 0.28f);
        c.drawArc(rect, 0, 180, false, line);
        c.drawLine(cx, cy + r * 0.28f, cx, cy + r * 0.5f, line);
        c.drawLine(cx - r * 0.2f, cy + r * 0.5f, cx + r * 0.2f, cy + r * 0.5f, line);
    }
}
