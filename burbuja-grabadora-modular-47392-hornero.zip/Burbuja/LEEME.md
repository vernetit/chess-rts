# Burbuja — grabadora flotante (47392-hornero)

App nativa Android 13, en Java y sin librerías. No armé el APK: revisé el código contra la API de Android 13 y probé la lógica de los archivos con audio real.

## Compilar en GitHub

1. Creá un repo nuevo y subí **el contenido** de la carpeta `Burbuja`, no la carpeta: `gradlew`, `settings.gradle` y `app/` tienen que quedar en la raíz del repo.
2. La carpeta `.github` es oculta. Si subís arrastrando desde la web y no aparece, creala a mano: **Add file → Create new file**, nombre `.github/workflows/apk.yml`, y pegás el contenido de ese archivo.
3. Andá a **Actions → APK**. Corre solo en cada push, o con **Run workflow**. Cuando termina, el APK está en **Artifacts → burbuja-apk**.

Lo que GitHub rebota son las acciones viejas. En septiembre de 2026 sacó Node 20 de sus máquinas, así que `checkout@v4`, `setup-java@v4` y `upload-artifact@v4` ya no corren. El workflow usa `checkout@v5`, `setup-java@v5` y `upload-artifact@v7`, que corren con Node 24, y deja Java 17 fijo (Gradle 8.7 falla con un Java más nuevo).

Otras opciones: Android Studio, o `./gradlew assembleDebug` en consola (necesitás JDK 17 y el SDK 34).

## Primer uso

1. Abrí la app y tocá **Permitir micrófono y notificaciones**.
2. Tocá **Permitir mostrar sobre otras apps**, activá Burbuja y volvé.
3. Opcional: **batería sin restricciones**, para que Motorola no la cierre.
4. Listo: la burbuja aparece sola.

## La burbuja

- **Tocar:** graba. Se pone roja con el tiempo, el aro se mueve con el volumen y vibra una vez.
- **Tocar otra vez:** para y vibra dos veces.
- **Arrastrar:** la movés. Si la soltás cerca del borde, se esconde la mitad.
- **Tocarla escondida:** sale y graba. Cuando parás, vuelve a esconderse.
- **Mantener apretada:** abre la lista de grabaciones.
- **Naranja:** Android le está tapando el micrófono. Cerrá la burbuja y volvé a abrirla desde la app.
- En la notificación también tenés **Grabar/Parar** y **Cerrar burbuja**.

## Grabaciones

- Cada día es un solo archivo (`2026-10-30.aac`). Cada vez que parás, el tramo se suma al final.
- A medianoche, si está grabando, cierra el archivo de ayer y sigue en el de hoy sin que toques nada.
- En la lista ves cada día con el total y sus tramos con la hora. Si tocás un tramo, se escucha desde ahí. Mientras suena, te dice a qué hora se grabó eso. Velocidad de 1× a 2×.
- **Compartir**, **A Descargas** (queda en `Download/Grabaciones/`) y **Borrar**.
- Se guardan en `Android/data/com.burbuja.grabadora/files/grabaciones`. Si desinstalás la app, se borran: lo que quieras conservar, pasalo antes a Descargas.
- Calidad: 32, 64 o 128 kbps, que son unos 14, 29 o 58 MB por hora. Un día entero grabando en Media ocupa unos 690 MB.

## Si se corta algo

- Mientras graba, el tramo va a un archivo aparte. Si Android cierra la app o se apaga el teléfono, la próxima vez que abre lo rescata. Pierde como mucho el último cuadro, 1/40 de segundo.
- Probado con audio real: pegar tramos, tramo repetido, pegado cortado a la mitad, final roto, índice roto o borrado. En ningún caso se pierde audio.

## Límites

- Después de reiniciar el teléfono, abrí la app una vez. Android no deja usar el micrófono a una burbuja que arranca sola.
- El tramo que se está grabando aparece en la lista cuando parás.
- El formato es `.aac`: lo abren WhatsApp, VLC y casi todos los reproductores.
