package com.moverdescargas.app;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Mueve un archivo SIN sobrescribir nunca nada. */
final class Mover {

    private Mover() {}

    /**
     * Busca un nombre libre (nombre.ext, nombre (1).ext, nombre (2).ext...)
     * y lo reserva creando un archivo vacío. createNewFile es atómico:
     * si el nombre ya existe devuelve false y se prueba el siguiente.
     */
    static File reservar(File carpeta, String nombre) throws IOException {
        int punto = nombre.lastIndexOf('.');
        String base = punto > 0 ? nombre.substring(0, punto) : nombre;
        String ext = punto > 0 ? nombre.substring(punto) : "";
        for (int i = 0; i < 100000; i++) {
            File f = new File(carpeta, i == 0 ? nombre : base + " (" + i + ")" + ext);
            if (f.createNewFile()) return f;   // reservado: este nombre es nuestro
        }
        throw new IOException("No encontré un nombre libre para " + nombre);
    }

    /** Devuelve dónde quedó el archivo. */
    static File mover(File origen, File carpeta) throws IOException {
        if (!carpeta.isDirectory() && !carpeta.mkdirs() && !carpeta.isDirectory()) {
            throw new IOException("No pude crear la carpeta " + carpeta);
        }
        File destino = reservar(carpeta, origen.getName());

        // rename() reemplaza solo el archivo vacío que reservamos recién.
        if (origen.renameTo(destino)) return destino;

        // Si renombrar no se pudo: copiar dentro de la reserva y borrar el original.
        long fecha = origen.lastModified();
        try (InputStream in = new FileInputStream(origen);
             OutputStream out = new FileOutputStream(destino)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } catch (IOException e) {
            if (destino.length() == 0) destino.delete();   // sacar la reserva vacía
            throw e;
        }
        destino.setLastModified(fecha);
        if (!origen.delete()) {
            throw new IOException("Copiado a " + destino + " pero no pude borrar el original");
        }
        return destino;
    }
}
