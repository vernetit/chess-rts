package com.moverdescargas.app;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** Pantalla: permisos, iniciar/detener, cuadro de reglas y registro. */
public class MainActivity extends Activity {

    private static final String PERMISO_NOTIF = "android.permission.POST_NOTIFICATIONS";

    private TextView estado, desdeTxt, vistaReglas, registro;
    private EditText reglas;
    private Button btnArchivos, btnBateria, btnServicio;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresco = new Runnable() {
        @Override
        public void run() {
            actualizar();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences p = Prefs.get(this);
        int pad = dp(14);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad);

        TextView titulo = new TextView(this);
        titulo.setText("Mover descargas");
        titulo.setTextSize(24);
        titulo.setTypeface(null, Typeface.BOLD);
        col.addView(titulo);

        estado = new TextView(this);
        estado.setTextSize(16);
        estado.setPadding(0, dp(8), 0, dp(8));
        col.addView(estado);

        btnArchivos = boton("1. Dar acceso a todos los archivos", v -> pedirArchivos());
        btnBateria = boton("2. Batería sin restricciones", v -> pedirBateria());
        btnServicio = boton("Iniciar", v -> alternarServicio());
        col.addView(btnArchivos);
        col.addView(btnBateria);

        // ---- Desde cuándo mover ----
        col.addView(subtitulo("Mover archivos desde"));
        desdeTxt = new TextView(this);
        desdeTxt.setTextSize(17);
        desdeTxt.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        col.addView(desdeTxt);
        LinearLayout filaDesde = new LinearLayout(this);
        filaDesde.setOrientation(LinearLayout.HORIZONTAL);
        Button btnElegir = boton("Elegir fecha y hora", v -> elegirFecha());
        Button btnAhora = boton("Desde ahora", v -> desdeAhora());
        filaDesde.addView(btnElegir, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        filaDesde.addView(btnAhora, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        col.addView(filaDesde);

        col.addView(btnServicio);

        col.addView(subtitulo("Reglas  (palabra = carpeta)"));

        reglas = new EditText(this);
        reglas.setText(p.getString(Prefs.REGLAS, Reglas.INICIAL));
        reglas.setTypeface(Typeface.MONOSPACE);
        reglas.setTextSize(14);
        reglas.setGravity(Gravity.TOP | Gravity.START);
        reglas.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        reglas.setHorizontallyScrolling(false);
        reglas.setMinLines(10);
        col.addView(reglas);

        col.addView(boton("Guardar reglas", v -> guardarReglas(true)));

        vistaReglas = new TextView(this);
        vistaReglas.setTypeface(Typeface.MONOSPACE);
        vistaReglas.setTextSize(13);
        vistaReglas.setPadding(0, dp(6), 0, dp(6));
        col.addView(vistaReglas);
        mostrarReglas(p.getString(Prefs.REGLAS, Reglas.INICIAL));

        col.addView(subtitulo("Registro"));
        registro = new TextView(this);
        registro.setTypeface(Typeface.MONOSPACE);
        registro.setTextSize(12);
        registro.setTextIsSelectable(true);
        col.addView(registro);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(col);
        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(PERMISO_NOTIF) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{PERMISO_NOTIF}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Si quedó marcada como activa pero Android la cerró, abrir la app la revive.
        if (Prefs.get(this).getBoolean(Prefs.ACTIVO, false) && !MoverService.vivo) {
            arrancarServicio(false);
        }
        handler.post(refresco);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refresco);
        super.onPause();
    }

    // ---------------------------------------------------------------

    private void actualizar() {
        SharedPreferences p = Prefs.get(this);
        boolean archivos = Environment.isExternalStorageManager();
        boolean bateria = getSystemService(PowerManager.class)
                .isIgnoringBatteryOptimizations(getPackageName());
        boolean notif = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(PERMISO_NOTIF) == PackageManager.PERMISSION_GRANTED;
        boolean vivo = MoverService.vivo;

        StringBuilder s = new StringBuilder();
        s.append(archivos ? "✔ " : "✘ ").append("Acceso a archivos\n");
        s.append(bateria ? "✔ " : "✘ ").append("Batería sin restricciones\n");
        s.append(notif ? "✔ " : "✘ ").append("Notificaciones\n");
        if (vivo) {
            s.append("● FUNCIONANDO · ").append(MoverService.movidos).append(" movidos");
        } else {
            s.append("○ Detenido");
        }
        estado.setText(s);

        long elegido = p.getLong(Prefs.ELEGIDO, 0);
        if (vivo) {
            desdeTxt.setText(Prefs.fecha(p.getLong(Prefs.DESDE, System.currentTimeMillis())));
        } else if (elegido > 0) {
            desdeTxt.setText(Prefs.fecha(elegido));
        } else {
            desdeTxt.setText("Ahora (al tocar Iniciar)");
        }

        btnArchivos.setVisibility(archivos ? View.GONE : View.VISIBLE);
        btnBateria.setVisibility(bateria ? View.GONE : View.VISIBLE);
        btnServicio.setText(vivo ? "Detener" : "Iniciar");
        registro.setText(p.getString(Prefs.LOG, ""));
    }

    private void alternarServicio() {
        if (MoverService.vivo) {
            Intent i = new Intent(this, MoverService.class).setAction(MoverService.ACCION_DETENER);
            startService(i);
            handler.postDelayed(this::actualizar, 300);
            return;
        }
        if (!Environment.isExternalStorageManager()) {
            toast("Primero dale acceso a todos los archivos.");
            pedirArchivos();
            return;
        }
        guardarReglas(false);
        arrancarServicio(true);
    }

    private void arrancarServicio(boolean nuevo) {
        Intent i = new Intent(this, MoverService.class).putExtra(MoverService.EXTRA_NUEVO, nuevo);
        try {
            startForegroundService(i);
        } catch (Exception e) {
            toast("No se pudo iniciar: " + e.getMessage());
        }
        handler.postDelayed(this::actualizar, 300);
    }

    private void guardarReglas(boolean avisar) {
        String texto = reglas.getText().toString();
        Prefs.get(this).edit().putString(Prefs.REGLAS, texto).apply();
        List<String> avisos = mostrarReglas(texto);
        if (avisar) {
            String msg = "Reglas guardadas.";
            if (!avisos.isEmpty()) msg += "\n" + String.join("\n", avisos);
            toast(msg);
        }
    }

    /** Muestra debajo del cuadro cómo quedó cada regla. */
    private List<String> mostrarReglas(String texto) {
        List<String> avisos = new ArrayList<>();
        List<Reglas.Regla> lista = Reglas.parsear(texto, avisos);
        StringBuilder s = new StringBuilder();
        if (lista.isEmpty()) s.append("Sin reglas: no se mueve nada.\n");
        for (Reglas.Regla r : lista) {
            s.append(r.palabra).append("  →  ").append(r.carpeta.getAbsolutePath()).append('\n');
        }
        for (String a : avisos) s.append("⚠ ").append(a).append('\n');
        vistaReglas.setText(s.toString().trim());
        return avisos;
    }

    /** Calendario y después reloj. Segundos en 0. */
    private void elegirFecha() {
        SharedPreferences p = Prefs.get(this);
        long base = p.getLong(Prefs.ELEGIDO, 0);
        if (base == 0) base = System.currentTimeMillis();
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(base);
        new DatePickerDialog(this, (vista, anio, mes, dia) ->
                new TimePickerDialog(this, (reloj, hh, mm) -> {
                    Calendar r = Calendar.getInstance();
                    r.set(anio, mes, dia, hh, mm, 0);
                    r.set(Calendar.MILLISECOND, 0);
                    fijarDesde(r.getTimeInMillis());
                }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show(),
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void fijarDesde(long ms) {
        SharedPreferences.Editor e = Prefs.get(this).edit().putLong(Prefs.ELEGIDO, ms);
        if (MoverService.vivo) e.putLong(Prefs.DESDE, ms);   // se aplica ya
        e.apply();
        toast("Mueve archivos desde " + Prefs.fecha(ms));
        actualizar();
    }

    private void desdeAhora() {
        long ahora = System.currentTimeMillis();
        SharedPreferences.Editor e = Prefs.get(this).edit().putLong(Prefs.ELEGIDO, 0);
        if (MoverService.vivo) e.putLong(Prefs.DESDE, ahora);
        e.apply();
        toast(MoverService.vivo ? "Mueve archivos desde " + Prefs.fecha(ahora)
                : "Moverá desde el momento en que toques Iniciar");
        actualizar();
    }

    private void pedirArchivos() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
        }
    }

    private void pedirBateria() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    // ---------------------------------------------------------------

    private Button boton(String texto, View.OnClickListener accion) {
        Button b = new Button(this);
        b.setText(texto);
        b.setAllCaps(false);
        b.setOnClickListener(accion);
        return b;
    }

    private TextView subtitulo(String texto) {
        TextView t = new TextView(this);
        t.setText(texto);
        t.setTextSize(18);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, dp(18), 0, dp(4));
        return t;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
