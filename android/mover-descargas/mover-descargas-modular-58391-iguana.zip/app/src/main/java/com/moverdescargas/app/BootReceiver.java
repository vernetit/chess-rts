package com.moverdescargas.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Al prender el celular (o al actualizar la app), vuelve a arrancar si estaba activa. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        String accion = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(accion)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(accion)) return;
        if (!Prefs.get(c).getBoolean(Prefs.ACTIVO, false)) return;
        try {
            c.startForegroundService(new Intent(c, MoverService.class));
        } catch (Exception e) {
            Prefs.log(c, "No pude arrancar solo: " + e.getMessage());
        }
    }
}
