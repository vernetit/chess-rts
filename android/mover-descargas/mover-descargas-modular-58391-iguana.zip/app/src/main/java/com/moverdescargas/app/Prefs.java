package com.moverdescargas.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Datos guardados de la app: reglas, estado, último latido y registro. */
final class Prefs {
    static final String REGLAS = "reglas";   // texto del cuadro de edición
    static final String ACTIVO = "activo";   // el usuario lo dejó encendido
    static final String DESDE = "desde";     // corte en uso: mueve archivos posteriores a esto
    static final String ELEGIDO = "elegido"; // fecha/hora elegida por el usuario (0 = "al tocar Iniciar")
    static final String LATIDO = "latido";   // última vez que el servicio estuvo vivo
    static final String LOG = "log";         // últimas líneas del registro

    private static final int MAX_LINEAS_LOG = 80;

    private Prefs() {}

    static SharedPreferences get(Context c) {
        return c.getApplicationContext().getSharedPreferences("mover", Context.MODE_PRIVATE);
    }

    static String hora(long ms) {
        return new SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new Date(ms));
    }

    static String fecha(long ms) {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.ROOT).format(new Date(ms));
    }

    /** Agrega una línea arriba del registro (lo más nuevo primero). */
    static synchronized void log(Context c, String linea) {
        SharedPreferences p = get(c);
        String texto = "[" + hora(System.currentTimeMillis()) + "] " + linea + "\n"
                + p.getString(LOG, "");
        int n = 0;
        for (int i = 0; i < texto.length(); i++) {
            if (texto.charAt(i) == '\n' && ++n >= MAX_LINEAS_LOG) {
                texto = texto.substring(0, i + 1);
                break;
            }
        }
        p.edit().putString(LOG, texto).apply();
    }
}
