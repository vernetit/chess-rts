package com.moverdescargas.app;

import android.os.Environment;

import java.io.File;
import java.io.IOException;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Reglas "palabra = carpeta": mismo formato que el viejo mover-config.txt. */
final class Reglas {

    static final String INICIAL = String.join("\n",
            "# ===== Reglas de Mover descargas =====",
            "#",
            "# Cada regla:   palabra = carpeta",
            "#   - Si el nombre del archivo contiene la palabra, va a esa carpeta.",
            "#   - Mayúsculas, minúsculas y acentos NO importan en la palabra.",
            "#   - Si ponés solo la palabra (sin \"= carpeta\"), la carpeta se llama igual.",
            "#   - Carpeta con nombre simple -> se crea dentro de Download.",
            "#     Carpeta con ruta completa (empieza con /) -> va ahí.",
            "#   - Varias reglas en una línea separadas por comas,",
            "#     o una por línea. Las dos formas valen.",
            "#   - Si un archivo coincide con varias reglas, gana la primera.",
            "#   - Lo que va después de # se ignora.",
            "#   - Tocá GUARDAR REGLAS para aplicar los cambios.",
            "#",
            "# Ejemplos (sacales el # para activarlos):",
            "# foto = imagenes, video = videos",
            "# pdf = /storage/emulated/0/Documents/pdfs",
            "# musica",
            "",
            "anki = anki",
            "mantis = mantis",
            "");

    private static final String[] TEMPORALES = {
            ".crdownload", ".part", ".partial", ".tmp", ".download", ".opdownload"
    };

    static final class Regla {
        final String clave;     // palabra normalizada (minúsculas, sin acentos)
        final String palabra;   // como la escribió el usuario
        final File carpeta;     // carpeta destino absoluta

        Regla(String clave, String palabra, File carpeta) {
            this.clave = clave;
            this.palabra = palabra;
            this.carpeta = carpeta;
        }
    }

    private Reglas() {}

    /** Carpeta Download del celular. */
    static File base() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
    }

    /** Carpetas a vigilar: Download y, si existe, Descargas. */
    static List<File> origenes() {
        List<File> lista = new ArrayList<>();
        File download = base();
        lista.add(download);
        File descargas = new File(Environment.getExternalStorageDirectory(), "Descargas");
        if (descargas.isDirectory() && !canonica(descargas).equals(canonica(download))) {
            lista.add(descargas);
        }
        return lista;
    }

    static String canonica(File f) {
        try {
            return f.getCanonicalPath();
        } catch (IOException e) {
            return f.getAbsolutePath();
        }
    }

    /** "ÁNKI", "Anki", "aNkI" -> "anki". */
    static String normalizar(String s) {
        String sinAcentos = Normalizer.normalize(s, Normalizer.Form.NFKD).replaceAll("\\p{M}+", "");
        return sinAcentos.toLowerCase(Locale.ROOT);
    }

    /** Descargas a medio terminar u ocultas: no se tocan. */
    static boolean esTemporal(String nombre) {
        String n = nombre.toLowerCase(Locale.ROOT);
        if (n.startsWith(".")) return true;
        for (String t : TEMPORALES) {
            if (n.endsWith(t)) return true;
        }
        return false;
    }

    /** Lee el texto del cuadro. En avisos deja los problemas encontrados. */
    static List<Regla> parsear(String texto, List<String> avisos) {
        List<Regla> reglas = new ArrayList<>();
        String[] lineas = texto.split("\n", -1);
        for (int nro = 0; nro < lineas.length; nro++) {
            String linea = lineas[nro];
            int numeral = linea.indexOf('#');
            if (numeral >= 0) linea = linea.substring(0, numeral);
            for (String entrada : linea.split(",")) {
                entrada = entrada.trim();
                if (entrada.isEmpty()) continue;
                String palabra, carpeta;
                int igual = entrada.indexOf('=');
                if (igual >= 0) {
                    palabra = entrada.substring(0, igual).trim();
                    carpeta = entrada.substring(igual + 1).trim();
                } else {
                    palabra = entrada;
                    carpeta = entrada;
                }
                if (palabra.isEmpty() || carpeta.isEmpty()) {
                    if (avisos != null) {
                        avisos.add("Línea " + (nro + 1) + ": regla incompleta \"" + entrada + "\"");
                    }
                    continue;
                }
                File destino = carpeta.startsWith("/") ? new File(carpeta) : new File(base(), carpeta);
                reglas.add(new Regla(normalizar(palabra), palabra, destino.getAbsoluteFile()));
            }
        }
        return reglas;
    }

    /** Primera regla cuya palabra está en el nombre, o null. */
    static Regla buscar(List<Regla> reglas, String nombreArchivo) {
        String n = normalizar(nombreArchivo);
        for (Regla r : reglas) {
            if (n.contains(r.clave)) return r;
        }
        return null;
    }
}
