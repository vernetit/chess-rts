package com.moverdescargas.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaScannerConnection;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Servicio en primer plano (con notificación fija): es lo que hace que
 * Android no cierre la app. Cada 2 segundos revisa Descargas.
 */
public class MoverService extends Service {

    static final String ACCION_DETENER = "com.moverdescargas.app.DETENER";
    static final String EXTRA_NUEVO = "nuevo";   // true = el usuario tocó Iniciar

    /** Para que la pantalla sepa si el servicio está vivo de verdad. */
    static volatile boolean vivo = false;
    static volatile int movidos = 0;

    private static final String CANAL = "mover";
    private static final int ID_NOTIF = 1;
    private static final long INTERVALO = 2000;          // ms entre escaneos
    private static final long ESPERA_ESTABLE = 2000;     // ms sin cambios = descarga terminada
    private static final long CADA_LATIDO = 10_000;      // ms entre latidos guardados
    private static final long MARGEN_REINICIO = 60_000;  // al revivir, mira 1 min hacia atrás

    private Thread hilo;
    private volatile boolean corriendo;
    private long umbral;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel canal = new NotificationChannel(
                CANAL, "Mover descargas", NotificationManager.IMPORTANCE_LOW);
        canal.setShowBadge(false);
        nm.createNotificationChannel(canal);
        try {
            startForeground(ID_NOTIF, notificacion("Vigilando Descargas"));
        } catch (Exception e) {
            Prefs.log(this, "Android no dejó arrancar el servicio: " + e.getMessage());
            stopSelf();
            return;
        }
        vivo = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = Prefs.get(this);

        if (!vivo) {   // startForeground falló en onCreate
            stopSelf();
            return START_NOT_STICKY;
        }

        if (intent != null && ACCION_DETENER.equals(intent.getAction())) {
            p.edit().putBoolean(Prefs.ACTIVO, false).apply();
            Prefs.log(this, "Detenido.");
            corriendo = false;
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }

        long ahora = System.currentTimeMillis();
        boolean nuevo = intent != null && intent.getBooleanExtra(EXTRA_NUEVO, false);
        if (nuevo || p.getLong(Prefs.DESDE, 0) == 0) {
            // Corte: la fecha/hora elegida en pantalla, o ahora si no se eligió ninguna
            long elegido = p.getLong(Prefs.ELEGIDO, 0);
            long corte = elegido > 0 ? elegido : ahora;
            p.edit().putLong(Prefs.DESDE, corte).putLong(Prefs.LATIDO, ahora).apply();
        }
        p.edit().putBoolean(Prefs.ACTIVO, true).apply();

        if (hilo == null || !hilo.isAlive()) {
            long desde = p.getLong(Prefs.DESDE, ahora);
            if (nuevo) {
                umbral = desde;
                Prefs.log(this, "Iniciado. Mueve archivos posteriores a " + Prefs.fecha(umbral) + ".");
            } else {
                // Revivió (Android la cerró, o se reinició el celular):
                // también mueve lo que llegó mientras estuvo caída.
                umbral = Math.max(desde, p.getLong(Prefs.LATIDO, desde) - MARGEN_REINICIO);
                Prefs.log(this, "Volvió a arrancar. Recupera archivos desde " + Prefs.fecha(umbral) + ".");
            }
            corriendo = true;
            hilo = new Thread(this::bucle, "mover-descargas");
            hilo.start();
        }
        // Si Android la mata, que la vuelva a arrancar
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        corriendo = false;
        vivo = false;
        if (hilo != null) hilo.interrupt();
        super.onDestroy();
    }

    // ---------------------------------------------------------------

    private void bucle() {
        SharedPreferences p = Prefs.get(this);
        List<File> origenes = Reglas.origenes();

        // Lo que ya estaba en Descargas al arrancar queda registrado.
        Set<String> iniciales = new HashSet<>();
        for (File dir : origenes) {
            File[] fs = dir.listFiles();
            if (fs != null) for (File f : fs) iniciales.add(f.getAbsolutePath());
        }

        Map<String, long[]> vistos = new HashMap<>();     // ruta -> {tamaño, fecha}
        Map<String, Long> primeraVez = new HashMap<>();   // ruta -> cuándo apareció
        Set<String> fallidos = new HashSet<>();           // errores: no reintentar
        String textoReglas = null;
        List<Reglas.Regla> reglas = new ArrayList<>();
        long ultimoLatido = 0;
        boolean avisoPermiso = false;
        long desdeVisto = p.getLong(Prefs.DESDE, umbral);

        while (corriendo) {
            try {
                // Si cambiaste la fecha/hora en pantalla, se aplica ya
                long d = p.getLong(Prefs.DESDE, desdeVisto);
                if (d != desdeVisto) {
                    desdeVisto = d;
                    umbral = d;
                    Prefs.log(this, "Nuevo corte: mueve archivos posteriores a " + Prefs.fecha(d) + ".");
                }

                // Releer reglas si se guardaron cambios
                String t = p.getString(Prefs.REGLAS, Reglas.INICIAL);
                if (!t.equals(textoReglas)) {
                    reglas = Reglas.parsear(t, null);
                    textoReglas = t;
                    Prefs.log(this, "Reglas cargadas: " + reglas.size() + ".");
                }

                if (!Environment.isExternalStorageManager()) {
                    if (!avisoPermiso) {
                        Prefs.log(this, "Falta el permiso de acceso a todos los archivos.");
                        actualizarNotificacion("Falta permiso de archivos");
                        avisoPermiso = true;
                    }
                } else {
                    if (avisoPermiso) {
                        avisoPermiso = false;
                        actualizarNotificacion("Vigilando Descargas");
                    }
                    long ahora = System.currentTimeMillis();
                    for (File dir : origenes) {
                        File[] fs = dir.listFiles();
                        if (fs == null) continue;
                        for (File f : fs) {
                            procesar(f, dir, ahora, reglas, iniciales, vistos, primeraVez, fallidos);
                        }
                    }
                }

                long ahora = System.currentTimeMillis();
                if (ahora - ultimoLatido >= CADA_LATIDO) {
                    p.edit().putLong(Prefs.LATIDO, ahora).apply();
                    ultimoLatido = ahora;
                }
            } catch (Exception e) {
                Prefs.log(this, "Error: " + e);
            }
            try {
                Thread.sleep(INTERVALO);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    private void procesar(File f, File dir, long ahora, List<Reglas.Regla> reglas,
                          Set<String> iniciales, Map<String, long[]> vistos,
                          Map<String, Long> primeraVez, Set<String> fallidos) {
        if (!f.isFile()) return;
        String ruta = f.getAbsolutePath();
        String nombre = f.getName();
        if (fallidos.contains(ruta) || Reglas.esTemporal(nombre)) return;

        Reglas.Regla regla = Reglas.buscar(reglas, nombre);
        if (regla == null) return;
        if (regla.carpeta.getAbsolutePath().equals(dir.getAbsolutePath())) return;  // ya está ahí

        long fecha = f.lastModified();
        long tam = f.length();

        // Nuevo = modificado después del corte, o aparecido después del corte
        Long visto = primeraVez.get(ruta);
        if (visto == null) {
            visto = ahora;
            primeraVez.put(ruta, visto);
        }
        boolean esNuevo = fecha > umbral || (!iniciales.contains(ruta) && visto > umbral);
        if (!esNuevo) return;

        // Esperar a que la descarga termine: mismo tamaño y fecha dos veces seguidas
        long[] firma = vistos.get(ruta);
        if (firma == null || firma[0] != tam || firma[1] != fecha || ahora - fecha < ESPERA_ESTABLE) {
            vistos.put(ruta, new long[]{tam, fecha});
            return;
        }

        try {
            File destino = Mover.mover(f, regla.carpeta);
            movidos++;
            Prefs.log(this, "[" + regla.palabra + "] " + nombre + " → "
                    + regla.carpeta.getName() + "/" + destino.getName());
            actualizarNotificacion("Último: " + destino.getName() + " · " + movidos + " movidos");
            // Avisar a la galería / otras apps que el archivo cambió de lugar
            MediaScannerConnection.scanFile(this,
                    new String[]{ruta, destino.getAbsolutePath()}, null, null);
        } catch (IOException e) {
            fallidos.add(ruta);
            Prefs.log(this, "Error moviendo " + nombre + " (no lo reintento): " + e.getMessage());
        }
        vistos.remove(ruta);
        primeraVez.remove(ruta);
    }

    // ---------------------------------------------------------------

    private Notification notificacion(String texto) {
        PendingIntent abrir = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(this, CANAL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Mover descargas")
                .setContentText(texto)
                .setContentIntent(abrir)
                .setOngoing(true)
                .setOnlyAlertOnce(true);
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    private void actualizarNotificacion(String texto) {
        try {
            getSystemService(NotificationManager.class).notify(ID_NOTIF, notificacion(texto));
        } catch (Exception ignored) {
            // sin permiso de notificaciones: el servicio sigue igual
        }
    }
}
